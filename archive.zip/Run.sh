python3 .list/vdos.py
bash .list/dosser.sh 
