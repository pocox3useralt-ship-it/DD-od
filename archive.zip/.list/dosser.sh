cd server
php -S 0.0.0.0:4444 &
sleep 2
xdg-open http://localhost:4444 2>/dev/null || open http://localhost:4444
